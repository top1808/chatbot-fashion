# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions
from rasa_sdk import Action

from utils.functionHelper import chose_size_from_height


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message(text="Hello World!")
#
#         return []

class CheckShirtSize(Action):
    def name(self):
        return "action_check_shirt_size"

    def run(self, dispatcher, tracker, domain):
        current_height = tracker.get_slot("cust_height")
        if not current_height:
            msg = "Xin lỗi tôi không biết chiều cao của bạn."
            dispatcher.utter_message(text=msg)
            return []
        get_size = chose_size_from_height(current_height)
        dispatcher.utter_message(text=f"Bạn cao {current_height} thì nên mặc áo size {get_size}")
        return []
